#!/bin/zsh
# Short, repeatable demonstrations for the Project 01 presentation.
cd "${0:A:h}" || exit 1

demo_choice="${1:-}"
if [[ -z "$demo_choice" ]]; then
    print "Pac-Man presentation demos"
    print "1  BFS: shortest route to one target"
    print "2  A*: visit all four corners"
    print "3  A*: collect all food"
    print "4  Food search one move at a time"
    print "5  Food search with animation delays removed"
    print "6  DFS: compare its route with BFS"
    read "demo_choice?Choose 1-6: "
fi

# Optional extra game arguments permit quiet verification and zoom overrides.
if (( $# > 0 )); then shift; fi
case "$demo_choice" in
    1|bfs) set -- -l mediumMaze -p SearchAgent -a fn=bfs -z 1.2 --frameTime 0.04 "$@" ;;
    2|corners) set -- -l mediumCorners -p AStarCornersAgent -z 1.3 --frameTime 0.04 "$@" ;;
    3|food) set -- -l trickySearch -p AStarFoodSearchAgent -z 1.6 --frameTime 0.04 "$@" ;;
    4|step) set -- -l trickySearch -p AStarFoodSearchAgent -z 1.6 --frameTime -1 "$@" ;;
    5|fast) set -- -l trickySearch -p AStarFoodSearchAgent -z 1.6 --frameTime 0 "$@" ;;
    6|dfs) set -- -l mediumMaze -p SearchAgent -a fn=dfs -z 1.2 --frameTime 0.04 "$@" ;;
    *) print "Choose 1-6, or use bfs, corners, food, step, fast, or dfs."; exit 2 ;;
esac
exec ./Run_Pacman.command "$@"
