# Project01: The Searchin' Pac-Man

Completed CSE 537 search project. Use **Python 3.11**. The implementation uses
only the Python standard library and the supplied project files.

## Run

Run commands in the extracted project directory:

```sh
python pacman.py -l mediumMaze -p SearchAgent -a fn=dfs
python pacman.py -l mediumMaze -p SearchAgent -a fn=bfs
python pacman.py -l mediumMaze -p SearchAgent -a fn=ucs
python pacman.py -l bigMaze -p SearchAgent -a fn=astar,heuristic=manhattanHeuristic
python pacman.py -l mediumDottedMaze -p StayEastSearchAgent
python pacman.py -l mediumScaryMaze -p StayWestSearchAgent
python pacman.py -l tinyCorners -p SearchAgent -a fn=bfs,prob=CornersProblem
python pacman.py -l mediumCorners -p AStarCornersAgent
python pacman.py -l trickySearch -p AStarFoodSearchAgent
```

Append `-q` to run without graphics, or `--frameTime 0` to speed up animation.
The graphical display requires Tkinter, as described in the assignment.

## Implementation

Only the two designated starter files were modified. All original supporting
files, layouts, signatures, aliases and UC Berkeley attribution notices remain.

| Question | Implementation |
| --- | --- |
| Q1 | DFS with a stack and expanded-state set |
| Q2 | BFS with a queue and discovery-time duplicate detection |
| Q3 | UCS with best known path costs and stale-entry rejection |
| Q4 | A* with g+h priority, goal-on-pop and reopening on improved g |
| Q5 | Immutable `(position, visited_corner_mask)` states |
| Q6 | Minimum Manhattan tour over unvisited corners, with cached suffix costs |
| Q7 | Nearest-food maze distance plus a minimum spanning tree of remaining food |

Search nodes use parent links to share path prefixes. UCS/A* assume nonnegative
step costs. All algorithms use hashable states, including the supplied Grid and
eight-puzzle objects. An empty list means either a zero-action solution or no
reachable goal; callers can distinguish these using the start-state goal test.

Both custom heuristics are admissible and consistent. The corner heuristic
solves a wall-free relaxation, with at most 24 visit orders. The food heuristic
uses unit-cost maze distances cached per food location and MST costs cached per
food subset. Complete arguments appear in the separate PDF report and comments.

## Reproduce validation and measurements

```sh
python -m unittest discover -s validation -p 'test_*.py' -v
python validation/run_examples.py
python validation/benchmark.py
```

The 13 local regression tests include 60 generated weighted graphs checked
against an independent reference, an inconsistent-admissible A* reopening case,
and exhaustive heuristic checks on four mazes. All 20 full-game examples pass.
The original archive contains autograder support classes but no `autograder.py`
or official test cases. These local tests do not replace the hidden course tests.

The benchmark writes `validation/benchmark_results.json` and `.csv`. It measures
30 cases with five cold untraced searches each, reporting median wall-clock time.
A separate cold `tracemalloc` run measures peak Python allocations. Measurement
includes heuristic construction and caches; excludes imports, layout parsing,
problem setup, path validation, graphics and game execution. KiB means 1024
bytes. This memory measure is not whole-process resident memory.

Recorded environment: CPython 3.11.16, macOS 26.6.2, Apple arm64, September 15,
2026. Timing is hardware-dependent; expansion counts are the more stable metric.
The raw JSON contains all timing samples. `tests_python311.log`, `examples.log`
and `benchmark.log` preserve the recorded validation evidence.

Optional Unix/macOS diagnostic:

```sh
python validation/medium_search_probe.py
```

This intentionally stops after five seconds with memory tracing enabled. The
108-food `mediumSearch` case did not finish within that diagnostic budget; its
partial results are not an optimal solution or an ordinary runtime benchmark.

## Results to discuss in the demonstration

- `mediumMaze`: DFS takes 130 moves; BFS/UCS/A* take 68. The PDF's DFS length is
  an approximate hint; this archive's actual layout and successor order produce
  the measured 130-move route. No layout has been changed to match a hint.
- `bigMaze`: A* with Manhattan distance expands 549 states versus UCS's 620.
- `mediumCorners`: A* returns the optimal 106-step path, expanding 741 states.
- `trickySearch`: A* returns the optimal 60-step path, expanding 255 states
  versus UCS's 16,688. This is below the stated 7,000-node extra-credit threshold.
- Fewer expansions do not guarantee less elapsed time: heuristic work and data
  structure overhead also matter. BFS minimizes moves, while UCS minimizes cost.

## Starter caveat and provenance

The starter `EightPuzzleSearchProblem.getStartState` refers to module-global
`puzzle`, which is set by the script's main block. The generic-state test sets
that same global and leaves the supplied supporting file unchanged.

The project framework is by UC Berkeley (http://ai.berkeley.edu), attributed in
the original source headers. Requirements come from `Project01-Fall2026.pdf`.
Implementation, verification and report preparation used OpenAI Codex assistance.
The two submission artifacts are `search.zip` and `Project01_Report.pdf`.
