"""Measure cold searches. Run from any directory: python validation/benchmark.py.

Five independent untraced timing runs and one separate tracemalloc run per case.
Each run gets a new problem and empty heuristic caches. Imports, layout parsing,
problem construction and path validation are outside the measurement window.
"""
import csv
import gc
import json
import platform
import statistics
import time
import tracemalloc
from datetime import datetime, timezone
from common import ROOT, make_problem, search_function, verify_path


def cases():
    for maze in ('tinyMaze', 'mediumMaze', 'bigMaze', 'openMaze'):
        for algorithm in ('dfs', 'bfs', 'ucs', 'astar'):
            yield maze, 'position', algorithm, 'unit'
    for maze, cost in (('mediumDottedMaze', 'east'), ('mediumScaryMaze', 'west')):
        for algorithm in ('bfs', 'ucs'):
            yield maze, 'position', algorithm, cost
    for maze in ('tinyCorners', 'mediumCorners'):
        for algorithm in ('bfs', 'astar'):
            yield maze, 'corners', algorithm, 'unit'
    for maze in ('testSearch', 'tinySearch', 'trickySearch'):
        for algorithm in ('ucs', 'astar'):
            yield maze, 'food', algorithm, 'unit'


def main():
    results = []
    for maze, kind, algorithm, cost in cases():
        function = search_function(algorithm, kind)
        timings = []
        signatures = []
        for _ in range(5):
            problem = make_problem(maze, kind, cost)
            gc.collect()
            started = time.perf_counter_ns()
            actions = function(problem)
            timings.append((time.perf_counter_ns() - started) / 1e6)
            signatures.append((len(actions), verify_path(problem, actions, kind), problem._expanded))
        problem = make_problem(maze, kind, cost)
        gc.collect()
        tracemalloc.start()
        actions = function(problem)
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        signatures.append((len(actions), verify_path(problem, actions, kind), problem._expanded))
        assert len(set(signatures)) == 1, 'Nondeterministic solution or expansion count'
        length, path_cost, expanded = signatures[0]
        result = dict(layout=maze, problem=kind, algorithm=algorithm, cost_function=cost,
                      steps=length, path_cost=path_cost, expanded=expanded,
                      median_ms=statistics.median(timings), min_ms=min(timings), max_ms=max(timings),
                      peak_kib=peak / 1024, timing_samples_ms=timings)
        results.append(result)
        print(f'{maze:18} {algorithm:5} steps={length:4} cost={path_cost:.9g} '
              f'expanded={expanded:6} ms={result["median_ms"]:.3f} KiB={peak/1024:.1f}', flush=True)
    output = ROOT / 'validation'
    metadata = dict(python=platform.python_version(), implementation=platform.python_implementation(),
                    platform=platform.platform(), machine=platform.machine(),
                    measured_at=datetime.now(timezone.utc).isoformat(), timing_repetitions=5,
                    memory='One separate cold tracemalloc peak; KiB = 1024 bytes; not process RSS')
    (output / 'benchmark_results.json').write_text(json.dumps({'environment': metadata, 'results': results}, indent=2))
    columns = [key for key in results[0] if key != 'timing_samples_ms']
    with (output / 'benchmark_results.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(results)


if __name__ == '__main__':
    main()
