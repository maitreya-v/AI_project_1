"""Run the assignment examples through the actual game engine in quiet mode."""
import subprocess
import sys
from common import ROOT


def examples():
    yield 'tinyMaze', 'SearchAgent', 'fn=tinyMazeSearch'
    for maze in ('tinyMaze', 'mediumMaze', 'bigMaze'):
        yield maze, 'SearchAgent', 'fn=dfs'
    for maze in ('mediumMaze', 'bigMaze'):
        yield maze, 'SearchAgent', 'fn=bfs'
    yield 'mediumMaze', 'SearchAgent', 'fn=ucs'
    yield 'mediumDottedMaze', 'StayEastSearchAgent', None
    yield 'mediumScaryMaze', 'StayWestSearchAgent', None
    yield 'bigMaze', 'SearchAgent', 'fn=astar,heuristic=manhattanHeuristic'
    for algorithm in ('dfs', 'bfs', 'ucs', 'astar'):
        yield 'openMaze', 'SearchAgent', 'fn=' + algorithm + ',heuristic=manhattanHeuristic'
    for maze in ('tinyCorners', 'mediumCorners'):
        yield maze, 'SearchAgent', 'fn=bfs,prob=CornersProblem'
    yield 'mediumCorners', 'AStarCornersAgent', None
    for maze in ('testSearch', 'tinySearch', 'trickySearch'):
        yield maze, 'AStarFoodSearchAgent', None


if __name__ == '__main__':
    count = 0
    for maze, agent, arguments in examples():
        command = [sys.executable, 'pacman.py', '-l', maze, '-p', agent, '-q', '-f']
        if arguments:
            command += ['-a', arguments]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=30)
        assert result.returncode == 0 and 'Win Rate:      1/1' in result.stdout, result.stdout + result.stderr
        print('PASS', ' '.join(command[1:]), flush=True)
        count += 1
    print(f'All {count} complete-game examples passed.')
