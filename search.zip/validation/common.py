"""Shared fixtures for reproducible validation; no third-party dependencies."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import layout
import pacman
import search
import searchAgents as agents
from game import Actions


def game_state(name):
    maze = layout.Layout((ROOT / 'layouts' / (name + '.lay')).read_text().splitlines())
    state = pacman.GameState()
    state.initialize(maze, 0)
    return state


def make_problem(name, kind='position', cost='unit'):
    state = game_state(name)
    if kind == 'corners':
        return agents.CornersProblem(state)
    if kind == 'food':
        return agents.FoodSearchProblem(state)
    cost_fn = {'unit': lambda p: 1, 'east': lambda p: 0.5 ** p[0],
               'west': lambda p: 2 ** p[0]}[cost]
    return agents.PositionSearchProblem(state, costFn=cost_fn, warn=False, visualize=False)


def search_function(name, kind='position'):
    if name != 'astar':
        return getattr(search, name)
    heuristic = {'position': agents.manhattanHeuristic,
                 'corners': agents.cornersHeuristic, 'food': agents.foodHeuristic}[kind]
    return lambda problem: search.astar(problem, heuristic)


def verify_path(problem, actions, kind='position'):
    """Replay without calling getSuccessors or contaminating expansion counts."""
    assert isinstance(actions, list)
    start = problem.getStartState()
    position = start if kind == 'position' else start[0]
    remaining = (set(problem.corners) - {position} if kind == 'corners'
                 else set(start[1].asList()) if kind == 'food' else set())
    for action in actions:
        assert action in ('North', 'South', 'East', 'West'), action
        dx, dy = Actions.directionToVector(action)
        position = (int(position[0] + dx), int(position[1] + dy))
        assert not problem.walls[position[0]][position[1]], 'Walked through wall'
        remaining.discard(position)
    assert position == problem.goal if kind == 'position' else not remaining
    return problem.getCostOfActions(actions)
