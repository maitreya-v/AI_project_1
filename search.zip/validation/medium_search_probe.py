"""A bounded diagnostic for the optional 108-food challenge, not a benchmark.

Unix/macOS only: SIGALRM stops search after five seconds. Tracemalloc is enabled,
so this diagnostic's elapsed time must not be compared with untraced timings.
"""
import gc
import json
import signal
import time
import tracemalloc
from common import ROOT, make_problem, search_function, verify_path


def time_limit(*_):
    raise TimeoutError('Five-second diagnostic budget exhausted')


if __name__ == '__main__':
    problem = make_problem('mediumSearch', 'food')
    gc.collect()
    signal.signal(signal.SIGALRM, time_limit)
    tracemalloc.start()
    started = time.perf_counter()
    signal.setitimer(signal.ITIMER_REAL, 5)
    actions = None
    try:
        actions = search_function('astar', 'food')(problem)
        status = 'completed'
    except TimeoutError:
        status = 'time limit reached; no complete solution returned'
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        elapsed = time.perf_counter() - started
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    result = dict(layout='mediumSearch', food_count=problem.start[1].count(), status=status,
                  elapsed_seconds=elapsed, expanded=problem._expanded, peak_kib=peak/1024,
                  timing_includes_tracemalloc=True)
    if actions is not None:
        result['path_cost'] = verify_path(problem, actions, 'food')
    (ROOT / 'validation' / 'medium_search_probe.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
