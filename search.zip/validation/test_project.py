"""Independent regression, reference-optimality and heuristic checks.

Run: python -m unittest discover -s validation -p 'test_*.py' -v
The supplied archive has no autograder.py or test_cases directory; these are
local checks, not a claim to have run the course's hidden autograder.
"""
import heapq
import random
import unittest
from collections import Counter, deque
from common import game_state, make_problem, verify_path, search, agents


class GraphProblem(search.SearchProblem):
    def __init__(self, edges, start='S', goal='G'):
        self.edges, self.start, self.goal = edges, start, goal
        self.expansions = Counter()

    def getStartState(self):
        return self.start

    def isGoalState(self, state):
        return state == self.goal

    def getSuccessors(self, state):
        self.expansions[state] += 1
        return [(target, (state, i), cost)
                for i, (target, cost) in enumerate(self.edges.get(state, []))]

    def getCostOfActions(self, actions):
        state, cost = self.start, 0
        for source, index in actions:
            assert source == state
            state, weight = self.edges[state][index]
            cost += weight
        assert state == self.goal
        return cost


def reference_cost(edges, start, goal, unit=False):
    """Independent Dijkstra implementation for generated integer-labelled graphs."""
    frontier, settled = [(0, start)], set()
    while frontier:
        cost, state = heapq.heappop(frontier)
        if state in settled:
            continue
        settled.add(state)
        if state == goal:
            return cost
        for target, weight in edges.get(state, []):
            if target not in settled:
                heapq.heappush(frontier, (cost + (1 if unit else weight), target))
    return None


def exhaustive_heuristic_check(problem, heuristic):
    """Enumerate reachable states and use reverse BFS for exact costs-to-goal."""
    start = problem.getStartState()
    queue, states, reverse, goals = deque([start]), {start}, {}, []
    transitions = 0
    while queue:
        state = queue.popleft()
        value = heuristic(state, problem)
        assert value >= 0
        if problem.isGoalState(state):
            assert value == 0
            goals.append(state)
        for child, _, step in problem.getSuccessors(state):
            assert value <= step + heuristic(child, problem), 'Inconsistent heuristic'
            reverse.setdefault(child, []).append(state)
            transitions += 1
            if child not in states:
                states.add(child)
                queue.append(child)
    exact = dict.fromkeys(goals, 0)
    queue = deque(goals)
    while queue:
        child = queue.popleft()
        for parent in reverse.get(child, []):
            if parent not in exact:
                exact[parent] = exact[child] + 1
                queue.append(parent)
    for state, cost in exact.items():
        assert heuristic(state, problem) <= cost, 'Inadmissible heuristic'
    print(f'\n{type(problem).__name__}: {len(states)} states, {transitions} transitions; '
          f'{len(exact)} exact distances checked.', flush=True)


class ProjectTests(unittest.TestCase):
    def test_start_at_goal(self):
        for function in (search.dfs, search.bfs, search.ucs, search.astar):
            problem = GraphProblem({}, start='G')
            self.assertEqual(function(problem), [])
            self.assertFalse(problem.expansions)

    def test_unreachable_goal_and_cycles(self):
        for function in (search.dfs, search.bfs, search.ucs, search.astar):
            problem = GraphProblem({'S': [('A', 1)], 'A': [('S', 1)]})
            self.assertEqual(function(problem), [])
            self.assertEqual(problem.expansions, {'S': 1, 'A': 1})

    def test_dfs_successor_order(self):
        problem = GraphProblem({'S': [('A', 1), ('B', 1)],
                                'A': [('G', 1)], 'B': [('C', 1)], 'C': [('G', 1)]})
        actions = search.dfs(problem)
        self.assertEqual(problem.getCostOfActions(actions), 3)
        self.assertNotIn('A', problem.expansions)

    def test_zero_cost_edges_and_stale_entries(self):
        for function in (search.ucs, search.astar):
            problem = GraphProblem({'S': [('A', 10), ('B', 0)],
                                    'B': [('A', 1), ('S', 0)], 'A': [('G', 20)]})
            self.assertEqual(problem.getCostOfActions(function(problem)), 21)
            self.assertEqual(problem.expansions['A'], 1)

    def test_goal_is_checked_on_pop(self):
        for function in (search.ucs, search.astar):
            problem = GraphProblem({'S': [('G', 10), ('A', 1)], 'A': [('G', 1)]})
            self.assertEqual(problem.getCostOfActions(function(problem)), 2)

    def test_astar_reopens_for_inconsistent_admissible_heuristic(self):
        problem = GraphProblem({'S': [('A', 3), ('B', 1)],
                                'B': [('A', 1)], 'A': [('G', 3)]})
        h = {'S': 5, 'A': 0, 'B': 4, 'G': 0}
        actions = search.astar(problem, lambda state, _: h[state])
        self.assertEqual(problem.getCostOfActions(actions), 5)
        self.assertEqual(problem.expansions['A'], 2)

    def test_generated_graphs_against_independent_reference(self):
        rng = random.Random(537)
        for _ in range(60):
            edges = {i: [(j, rng.randrange(0, 12)) for j in range(12)
                         if i != j and rng.random() < .18] for i in range(12)}
            # Guarantee one route, while preserving random cycles and shortcuts.
            for i in range(11):
                edges[i].append((i + 1, rng.randrange(0, 12)))
            optimum = reference_cost(edges, 0, 11)
            for function in (search.ucs, search.astar):
                problem = GraphProblem(edges, 0, 11)
                self.assertEqual(problem.getCostOfActions(function(problem)), optimum)
            # Random admissible estimates need not be consistent; test general
            # A* against exact optimal costs, including possible reopenings.
            h = {i: int(reference_cost(edges, i, 11) * rng.random()) for i in range(12)}
            problem = GraphProblem(edges, 0, 11)
            actions = search.astar(problem, lambda state, _: h[state])
            self.assertEqual(problem.getCostOfActions(actions), optimum)
            problem = GraphProblem(edges, 0, 11)
            self.assertEqual(len(search.bfs(problem)), reference_cost(edges, 0, 11, unit=True))

    def test_corners_state_independence_and_start_corner(self):
        state = game_state('tinyCorners')
        state.data.agentStates[0].configuration.pos = (1, 1)
        problem = agents.CornersProblem(state)
        start = problem.getStartState()
        self.assertEqual(start, ((1, 1), 1))
        children = problem.getSuccessors(start)
        self.assertEqual(start, problem.getStartState())
        self.assertTrue(all(cost == 1 and child[1] & 1 for child, _, cost in children))
        self.assertTrue(problem.isGoalState(((1, 1), 15)))
        self.assertFalse(problem.isGoalState(((1, 1), 1)))

    def test_corners_exhaustive_admissibility_and_consistency(self):
        for name in ('tinyCorners', 'mediumCorners'):
            exhaustive_heuristic_check(make_problem(name, 'corners'), agents.cornersHeuristic)

    def test_food_exhaustive_admissibility_and_consistency(self):
        for name in ('testSearch', 'tinySearch'):
            exhaustive_heuristic_check(make_problem(name, 'food'), agents.foodHeuristic)

    def test_food_grid_not_mutated_and_empty_goal(self):
        problem = make_problem('tinySearch', 'food')
        start = problem.getStartState()
        saved = start[1].copy()
        agents.foodHeuristic(start, problem)
        problem.getSuccessors(start)
        self.assertEqual(start[1], saved)
        empty = saved.copy()
        for x, y in empty.asList():
            empty[x][y] = False
        self.assertEqual(agents.foodHeuristic((start[0], empty), problem), 0)

    def test_optimality_and_assignment_thresholds(self):
        for maze, kind, expected, threshold in (
                ('tinyCorners', 'corners', 28, None),
                ('mediumCorners', 'corners', 106, 800),
                ('testSearch', 'food', 7, None),
                ('tinySearch', 'food', 27, None),
                ('trickySearch', 'food', 60, 7000)):
            baseline = make_problem(maze, kind)
            best = search.ucs(baseline)
            problem = make_problem(maze, kind)
            heuristic = agents.cornersHeuristic if kind == 'corners' else agents.foodHeuristic
            actions = search.astar(problem, heuristic)
            self.assertEqual(verify_path(problem, actions, kind), len(best))
            self.assertEqual(len(actions), expected)
            if threshold:
                self.assertLess(problem._expanded, threshold)

    def test_eight_puzzle_generic_state_support(self):
        import eightpuzzle
        # The starter's getStartState references a module-global puzzle.
        # Set it exactly as eightpuzzle.py's main block does; preserve starter.
        eightpuzzle.puzzle = eightpuzzle.loadEightPuzzle(0)
        for function in (search.bfs, search.ucs, search.astar):
            problem = eightpuzzle.EightPuzzleSearchProblem(eightpuzzle.puzzle)
            actions = function(problem)
            current = eightpuzzle.puzzle
            for action in actions:
                current = current.result(action)
            self.assertTrue(current.isGoal())
            self.assertEqual(len(actions), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
