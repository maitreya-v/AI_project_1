# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from game import Directions
from typing import List

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()




def tinyMazeSearch(problem: SearchProblem) -> List[Directions]:
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem: SearchProblem) -> List[Directions]:
    """
    Return a graph-DFS path, expanding each hashable state at most once.

    Mark states on removal from the stack so duplicate frontier entries do
    not suppress a deeper route prematurely. Complete on finite graphs;
    the first solution is not necessarily shortest or cheapest.
    """
    # A node is (state, parent_node, incoming_action). Parent links share
    # prefixes instead of copying the full action list for every successor.
    frontier = util.Stack()
    frontier.push((problem.getStartState(), None, None))
    expanded = set()
    while not frontier.isEmpty():
        node = frontier.pop()
        state = node[0]
        if state in expanded:
            continue
        if problem.isGoalState(state):
            return _reconstructActions(node)
        expanded.add(state)
        # Preserve the problem's order: the last successor is explored first.
        for successor, action, _ in problem.getSuccessors(state):
            if successor not in expanded:
                frontier.push((successor, node, action))
    return []  # No goal is reachable.

def breadthFirstSearch(problem: SearchProblem) -> List[Directions]:
    """Search the shallowest nodes in the search tree first."""
    frontier = util.Queue()
    start = problem.getStartState()
    frontier.push((start, None, None))
    # First discovery is a shortest path in number of actions. Marking on
    # insertion prevents multiple queued copies of the same state.
    discovered = {start}
    while not frontier.isEmpty():
        node = frontier.pop()
        state = node[0]
        if problem.isGoalState(state):
            return _reconstructActions(node)
        for successor, action, _ in problem.getSuccessors(state):
            if successor not in discovered:
                discovered.add(successor)
                frontier.push((successor, node, action))
    return []

def uniformCostSearch(problem: SearchProblem) -> List[Directions]:
    """Search the node of least total cost first."""
    return _costSearch(problem, nullHeuristic)

def nullHeuristic(state, problem=None) -> float:
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem: SearchProblem, heuristic=nullHeuristic) -> List[Directions]:
    """Search the node that has the lowest combined cost and heuristic first."""
    return _costSearch(problem, heuristic)


def _reconstructActions(node):
    """Follow immutable parent links, then put the actions in forward order."""
    actions = []
    while node[1] is not None:
        actions.append(node[2])
        node = node[1]
    actions.reverse()
    return actions


def _costSearch(problem, heuristic):
    """UCS/A* graph search for nonnegative costs and hashable states.

    Keep the cheapest discovered g-value for each state. An improved route
    gets a new priority-queue entry; obsolete entries are discarded on pop.
    A state can reopen if a cheaper route is found, so A* also handles
    admissible but inconsistent heuristics. Goal testing happens on pop,
    never on generation. Equal priorities retain util.PriorityQueue's FIFO
    tie order; equal-cost duplicate paths are not queued.
    """
    start = problem.getStartState()
    frontier = util.PriorityQueue()
    frontier.push(((start, None, None), 0), heuristic(start, problem))
    bestCost = {start: 0}
    while not frontier.isEmpty():
        node, cost = frontier.pop()
        state = node[0]
        if cost != bestCost[state]:
            continue
        if problem.isGoalState(state):
            return _reconstructActions(node)
        for successor, action, stepCost in problem.getSuccessors(state):
            nextCost = cost + stepCost
            if successor not in bestCost or nextCost < bestCost[successor]:
                bestCost[successor] = nextCost
                nextNode = (successor, node, action)
                frontier.push((nextNode, nextCost),
                              nextCost + heuristic(successor, problem))
    return []

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
