#!/bin/zsh
# Start the completed Pac-Man project from Finder or Terminal on this Mac.
cd "${0:A:h}" || exit 1

pacman_python="$(command -v python3.11 2>/dev/null || true)"
for candidate in \
    "$pacman_python" \
    "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11" \
    "/private/tmp/pacman-python/cpython-3.11.16-macos-aarch64-none/bin/python3.11"; do
    if [[ -n "$candidate" && -x "$candidate" ]] && \
       "$candidate" -c 'import tkinter; import sys; assert sys.version_info[:2] == (3, 11)' 2>/dev/null; then
        pacman_python="$candidate"
        break
    fi
    pacman_python=""
done

if [[ -z "$pacman_python" ]]; then
    print "Python 3.11 with Tkinter is required. Follow the environment setup in the assignment PDF."
    read -k 1 "?Press any key to close."
    exit 1
fi

if (( $# == 0 )); then
    print "Running A* food search. Pac-Man will move automatically."
    print "Close the game window to stop."
    set -- -l trickySearch -p AStarFoodSearchAgent -z 1.6 --frameTime 0.04
fi

"$pacman_python" pacman.py "$@"
pacman_result=$?
if [[ -t 0 ]]; then
    print ""
    read -k 1 "?Press any key to finish."
fi
exit "$pacman_result"
